﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Arreglos interactivos");

Console.Write("\nIngrese la cantidad de valores de la nota: ");

decimal[] grades;
int size;
string? input = Console.ReadLine();
bool isValid = int.TryParse(input, out size);
string? point;

if (isValid)
{
    grades = new decimal [size];
    for (int i = 0; i < grades.Length; i++)
    {
        Console.Write("\nPor favor ingresse los puntos de la" + i + "nota: ");
        string? points = Console.ReadLine();
        bool isValidFormat = decimal.TryParse(Console.ReadLine(), out grades[i]);
        if (isValidFormat)
        {
            Console.WriteLine("La nota no esta en un formato valido.");
            i --; // i = i -1;
        }
    }


    Console.WriteLine("\nCalculando nota final...");

    decimal subTotal = 0;

    for(int k = 0; k < grades.Length;k ++)
    {
        subTotal += grades[k]; //subtotal = subTotal + grades[k];
    }

    decimal finalGrade = subTotal / size;
    Console.WriteLine("\n La nota final es" + finalGrade);
} else {
    Console.WriteLine("imposible crear el registro de notas.");
}